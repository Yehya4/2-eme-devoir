/*
 * TP IoT HTTP - Version Allégée et Stabilisée (Anti-Crash)
 */

#include <Arduino.h>
#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <ArduinoJson.h>

#define USE_SERIAL Serial

/* ---- Configuration WiFi ---- */
const char* WIFI_SSID     = "EMSI_Etud";
const char* WIFI_PASSWORD = "";

/* ---- Identite et localisation de l'ESP ---- */
String esp_user  = "GM";
String esp_loc   = "Biot";
String esp_ident = "ESP32_01";

/* ---- Configuration GPIO & Variables d'etat ---- */
const int LEDpin = 19;
String LEDState  = "off";
String last_temp = "25.12";
String last_light = "1070";

// Parametres de reporting vers Node-RED
String target_ip   = "192.168.52.1"; // Mettre l'adresse IP de votre PC
int    target_port = 1880;
int    target_sp   = 10; // En secondes

unsigned long last_report_tick = 0;

// Serveur Web Asynchrone sur le port 80
AsyncWebServer server(80);

/* ---- Construction du JSON de statut ---- */
String buildStatusJson() {
  StaticJsonDocument<256> doc;

  JsonObject status = doc.createNestedObject("status");
  status["temperature"] = 25.12;
  status["light"]       = 1070;
  status["led"]         = LEDState;
  status["fire"]        = false;
  status["running"]     = true;

  JsonObject info = doc.createNestedObject("info");
  info["loc"]   = esp_loc;
  info["user"]  = esp_user;
  info["ident"] = esp_ident;

  JsonObject net = doc.createNestedObject("net");
  net["uptime"] = String(millis() / 1000);
  net["ssid"]   = (WiFi.status() == WL_CONNECTED) ? WiFi.SSID() : "Deconnecte";
  net["mac"]    = WiFi.macAddress();
  net["ip"]     = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : "0.0.0.0";

  JsonObject reporthost = doc.createNestedObject("reporthost");
  reporthost["target_ip"]   = target_ip;
  reporthost["target_port"] = target_port;
  reporthost["sp"]          = target_sp;

  String output;
  serializeJson(doc, output);
  return output;
}

/* ---- Processor pour les Placeholders de index.html ---- */
String processor(const String& var) {
  if (var == "UPTIME")      return String(millis() / 1000);
  if (var == "WHERE")       return esp_loc;
  if (var == "SSID")        return (WiFi.status() == WL_CONNECTED) ? WiFi.SSID() : "Non connecte";
  if (var == "MAC")         return WiFi.macAddress();
  if (var == "IP")          return (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : "0.0.0.0";
  if (var == "TEMPERATURE") return last_temp;
  if (var == "LIGHT")       return last_light;
  if (var == "COOLER")      return "off";
  if (var == "HEATER")      return "off";
  if (var == "LT")          return "18.0";
  if (var == "HT")          return "28.0";
  if (var == "PRT_IP")      return target_ip;
  if (var == "PRT_PORT")    return String(target_port);
  if (var == "PRT_T")       return String(target_sp);
  return String();
}

/* ---- Configuration des routes Web ---- */
void setup_http_routes() {
  // Page racine avec les placeholders
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/index.html", String(), false, processor);
  });

  // Fichier CSS
  server.on("/esp.css", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(LittleFS, "/esp.css", "text/css");
  });

  // Routes AJAX / Fetch
  server.on("/temperature", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(200, "text/plain", last_temp);
  });

  server.on("/light", HTTP_GET, [](AsyncWebServerRequest *request) {
    request->send(200, "text/plain", last_light);
  });

  // Formulaire de reporting POST /target
  server.on("/target", HTTP_POST, [](AsyncWebServerRequest *request) {
    if (request->hasArg("ip") && request->hasArg("port") && request->hasArg("sp")) {
      target_ip   = request->arg("ip");
      target_port = request->arg("port").toInt();
      target_sp   = request->arg("sp").toInt();
    }
    request->send(LittleFS, "/index.html", String(), false, processor);
  });

  // Route /status pour Node-RED
  server.on("/status", HTTP_GET, [](AsyncWebServerRequest *request) {
    AsyncWebServerResponse *response = request->beginResponse(200, "application/json", buildStatusJson());
    response->addHeader("Access-Control-Allow-Origin", "*");
    request->send(response);
  });

  // Route /led
  server.on("/led", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (request->hasArg("state")) {
      String st = request->arg("state");
      digitalWrite(LEDpin, (st == "on") ? HIGH : LOW);
      LEDState = (st == "on") ? "on" : "off";
    }
    AsyncWebServerResponse *response = request->beginResponse(200, "application/json", buildStatusJson());
    response->addHeader("Access-Control-Allow-Origin", "*");
    request->send(response);
  });

  server.onNotFound([](AsyncWebServerRequest *request) {
    request->send(404, "text/plain", "Not Found");
  });
}

/* ---- Envoi periodique POST /esp vers Node-RED ---- */
void sendPeriodicReport() {
  if (WiFi.status() != WL_CONNECTED || target_sp <= 0) return;

  HTTPClient http;
  String url = "http://" + target_ip + ":" + String(target_port) + "/esp?mac=" + WiFi.macAddress();
  
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(buildStatusJson());
  Serial.printf("[POST /esp] Code retour : %d\n", code);
  http.end();
}

void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(LEDpin, OUTPUT);
  digitalWrite(LEDpin, LOW);

  // Montage LittleFS
  if (!LittleFS.begin(true)) {
    Serial.println("Erreur LittleFS");
    return;
  }

  // Connexion WiFi
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  
  while (WiFi.status() != WL_CONNECTED && millis() - start < 15000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\nWiFi connecte ! IP : %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\nEchec de connexion WiFi !");
  }

  // Demarrage serveur
  setup_http_routes();
  server.begin();
  Serial.println("Serveur pret !");
}

void loop() {
  unsigned long now = millis();

  // Reporting periodique non-bloquant
  if (target_sp > 0 && (now - last_report_tick >= (unsigned long)target_sp * 1000UL)) {
    last_report_tick = now;
    sendPeriodicReport();
  }
}