========================================================================
GUIDE D'INSTALLATION & COMMANDES cURL DE TEST (TODO: Final Step of Lab)
========================================================================

1. STRUCTURE DE L'ARCHIVE
-------------------------
- esp32_dash_wifi_littlefs/
  ├── esp32_dash_wifi_littlefs.ino  (Code Arduino ESPAsyncWebServer + HTTPClient)
  └── data/
      ├── index.html                (Page d'admin avec Placeholders %...% et formulaire /target)
      └── esp.css                   (Feuille de style CSS de la page d'admin)
- flow_nodered_complet.json         (Flow Node-RED avec [POST] /esp, validateur et Dashboard)
- schema_validateur.json            (Schema JSON Draft-07 du statut de l'ESP32)

2. ETAPES SUR ARDUINO IDE
-------------------------
a) Ouvrir esp32_dash_wifi_littlefs/esp32_dash_wifi_littlefs.ino
b) Modifier WIFI_SSID et WIFI_PASSWORD si necessaire.
c) Televerser le dossier data/ (index.html + esp.css) dans la memoire Flash LittleFS de l'ESP32.
d) Compiler et televerser le sketch .ino sur l'ESP32.
e) Ouvrir le Moniteur Serie (9600 bauds) pour noter l'adresse IP de l'ESP32.

3. COMMANDES cURL POUR TESTER CHAQUE PARTIE DU CAHIER DES CHARGES
-----------------------------------------------------------------
(Remplacer <IP_ESP> par l'IP de votre ESP32 et <IP_NODERED> par l'IP de votre PC)

A) Section 4.1.1 - Page d'administration (GET /) :
   Dans un navigateur : http://<IP_ESP>/
   Ou en ligne de commande :
   curl -i http://<IP_ESP>/

B) Section 4.1.3 - "Get a value" de l'ESP (GET /value) :
   - Recuperer temperature et lumiere en JSON :
     curl -i "http://<IP_ESP>/value?temperature&light"
   - Recuperer les 5 parametres autorises (temperature, light, fire, ht, lt) :
     curl -i "http://<IP_ESP>/value?temperature&light&fire&ht&lt"
   - Tester un parametre inconnu (doit renvoyer HTTP 404) :
     curl -i "http://<IP_ESP>/value?inconnu"

C) Section 4.1.4 - "Set a value" de l'ESP (GET /set) :
   - Allumer le cooler :
     curl -i "http://<IP_ESP>/set?cool=on"
   - Allumer le heater et modifier les seuils HT et LT :
     curl -i "http://<IP_ESP>/set?heat=on&lt=19.5&ht=29.0"
   - Tester un parametre inconnu (doit renvoyer HTTP 404) :
     curl -i "http://<IP_ESP>/set?wrong=123"

D) Section 4.1.2 - Configurer le reporting periodique (POST /target) :
   Depuis le formulaire de la page http://<IP_ESP>/ ou via cURL :
   curl -i -X POST "http://<IP_ESP>/target" -d "ip=<IP_NODERED>&port=1880&sp=5"
   (Mettre sp=0 pour stopper l'envoi periodique)

E) Section 4.2.1 - Simuler l'ESP32 vers le Dashboard Node-RED (POST /esp?mac=...) :
   curl -v -X POST -H "Content-Type: application/json" \
   -d '{"status":{"temperature":24.5,"light":1234,"led":"off","fire":false,"running":true},"info":{"loc":"Biot","user":"GM","ident":"ESP32_01"},"net":{"uptime":"120","ssid":"Orange_5G","mac":"38:14:28:db:56:9d","ip":"192.168.1.45"}}' \
   "http://localhost:1880/esp?mac=38:14:28:db:56:9d"
