/* Controle independant des trames ESP32 selon le contrat JSON du tableau de bord.
   Execution depuis un terminal : node validateur.js fichier.json
   Necessite uniquement Node.js, sans paquet supplementaire.
*/
const fs = require('node:fs');
const fichierEntree = process.argv[2];
if (!fichierEntree) {
    console.log('Utilisation : node validateur.js fichier.json');
    process.exit(2);
}
let d;
try {
    d = JSON.parse(fs.readFileSync(fichierEntree, 'utf8'));
} catch (e) {
    console.error('JSON REJETE : fichier illisible ou syntaxe JSON invalide : ' + e.message);
    process.exit(1);
}
const anomalies = [];
function signaler(emplacement, message) { anomalies.push(emplacement + ' : ' + message); }
function estObjetSimple(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
function estNombreValide(v) { return typeof v === 'number' && Number.isFinite(v); }
function estEntier(v) { return estNombreValide(v) && Number.isInteger(v); }
function verifierProprietes(obj, emplacement, clesAttendues) {
    if (!estObjetSimple(obj)) { signaler(emplacement, 'estObjetSimple attendu'); return false; }
    for (const propriete of clesAttendues) {
        if (!Object.prototype.hasOwnProperty.call(obj, propriete)) signaler(emplacement + '.' + propriete, 'champ manquant');
    }
    for (const propriete of Object.keys(obj)) {
        if (!clesAttendues.includes(propriete)) signaler(emplacement + '.' + propriete, 'champ inconnu');
    }
    return true;
}
function verifierTexte(v, emplacement) {
    if (typeof v !== 'string' || v.trim() === '') signaler(emplacement, 'chaine non vide attendue');
}
function verifierChoix(v, emplacement, options) {
    if (!options.includes(v)) signaler(emplacement, 'valeur autorisee : ' + options.join(', '));
}
if (!verifierProprietes(d, 'root', ['status', 'location', 'regul', 'info', 'net', 'reporthost'])) {
    console.error('JSON REJETE :\n' + anomalies.join('\n'));
    process.exit(1);
}
if (verifierProprietes(d.status, 'status', ['temperature', 'light', 'regul', 'fire', 'heat', 'cold', 'fanspeed'])) {
    const s = d.status;
    if (s.temperature !== null && (!estNombreValide(s.temperature) || s.temperature < -55 || s.temperature > 125))
        signaler('status.temperature', 'temperature invalide pour DS18B20');
    if (!estEntier(s.light) || s.light < 0 || s.light > 4095)
        signaler('status.light', 'estEntier entre 0 et 4095 attendu');
    verifierChoix(s.regul, 'status.regul', ['RUNNING', 'HALT']);
    verifierChoix(s.heat, 'status.heat', ['ON', 'OFF']);
    verifierChoix(s.cold, 'status.cold', ['ON', 'OFF']);
    if (typeof s.fire !== 'boolean') signaler('status.fire', 'booleen attendu');
    if (!estEntier(s.fanspeed) || s.fanspeed < 0 || s.fanspeed > 255)
        signaler('status.fanspeed', 'estEntier entre 0 et 255 attendu');
    if (s.heat === 'ON' && s.cold === 'ON') signaler('status', 'chauffage et climatisation simultanes');
    if (s.regul === 'HALT' && (s.heat === 'ON' || s.cold === 'ON'))
        signaler('status', 'action active alors que regulation arretee');
}
if (verifierProprietes(d.location, 'location', ['room', 'gps', 'address'])) {
    verifierTexte(d.location.room, 'location.room');
    verifierTexte(d.location.address, 'location.address');
    if (verifierProprietes(d.location.gps, 'location.gps', ['lat', 'lon'])) {
        const gps = d.location.gps;
        if (!estNombreValide(gps.lat) || gps.lat < -90 || gps.lat > 90) signaler('location.gps.lat', 'latitude invalide');
        if (!estNombreValide(gps.lon) || gps.lon < -180 || gps.lon > 180) signaler('location.gps.lon', 'longitude invalide');
    }
}
if (verifierProprietes(d.regul, 'regul', ['lt', 'ht'])) {
    if (!estNombreValide(d.regul.lt)) signaler('regul.lt', 'estNombreValide attendu');
    if (!estNombreValide(d.regul.ht)) signaler('regul.ht', 'estNombreValide attendu');
    if (estNombreValide(d.regul.lt) && estNombreValide(d.regul.ht) && d.regul.lt >= d.regul.ht)
        signaler('regul', 'lt doit etre inferieur a ht');
}
if (verifierProprietes(d.info, 'info', ['ident', 'user', 'loc'])) {
    verifierTexte(d.info.ident, 'info.ident');
    verifierTexte(d.info.user, 'info.user');
    verifierTexte(d.info.loc, 'info.loc');
}
if (verifierProprietes(d.net, 'net', ['uptime', 'ssid', 'mac', 'ip'])) {
    verifierTexte(d.net.uptime, 'net.uptime');
    verifierTexte(d.net.ssid, 'net.ssid');
    verifierTexte(d.net.mac, 'net.mac');
    verifierTexte(d.net.ip, 'net.ip');
    if (typeof d.net.uptime === 'string' && !/^\d+$/.test(d.net.uptime))
        signaler('net.uptime', 'estEntier positif sous forme de verifierTexte attendu');
}
if (verifierProprietes(d.reporthost, 'reporthost', ['target_ip', 'target_port', 'sp'])) {
    verifierTexte(d.reporthost.target_ip, 'reporthost.target_ip');
    if (!estEntier(d.reporthost.target_port) || d.reporthost.target_port < 1 || d.reporthost.target_port > 65535)
        signaler('reporthost.target_port', 'port invalide');
    if (!estEntier(d.reporthost.sp) || d.reporthost.sp <= 0)
        signaler('reporthost.sp', 'estEntier positif attendu');
}
if (anomalies.length > 0) {
    console.error('JSON REJETE (' + anomalies.length + ' erreur(s)) :\n' + anomalies.join('\n'));
    process.exit(1);
}
console.log('JSON ACCEPTE : ' + fichierEntree);
