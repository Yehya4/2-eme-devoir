/*
 * Projet IoT ESP32 Optimise Memoire (Flash & RAM)
 * Cahier des charges TP HTTP (Pages 44-47)
 */

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <OneWire.h>
#include <DallasTemperature.h>

/* ---- 1. Configuration WiFi ---- */
const char* WIFI_SSID     = "Galaxy A124E16";
const char* WIFI_PASSWORD = "123456789";

/* ---- 2. Configuration Dynamique du Reporting (POST /target) ---- */
String target_ip   = "10.241.32.89";
int    target_port = 1880;
int    target_sp   = 10; // Periode en secondes (0 = bloque l'envoi)
unsigned long last_tick = 0;

/* ---- 3. Materiel / GPIO & Variables d'etat ---- */
const uint8_t LEDpin   = 19;
const uint8_t LightPin = 33;

OneWire oneWire(23);
DallasTemperature tempSensor(&oneWire);

bool   ledOn       = false;
bool   coolerOn    = false;
bool   heaterOn    = false;
bool   fireDetected = false;
float  last_temp   = 25.0f;
int    last_light  = 500;

float low_temp_threshold  = 18.0f; // LT
float high_temp_threshold = 28.0f; // HT
int   light_threshold     = 250;

WebServer server(80);
char jsonBuffer[512]; // Buffer statique unique pour eviter la fragmentation RAM

/* ---- 4. Lecture Capteurs & Regulation ---- */
void updateSensorsAndRegulation() {
  tempSensor.requestTemperatures();
  float t = tempSensor.getTempCByIndex(0);
  last_temp    = (t == DEVICE_DISCONNECTED_C || t < -50.0f) ? 25.12f : t;
  last_light   = analogRead(LightPin);
  fireDetected = (last_temp > 30.0f);

  if (last_temp < low_temp_threshold) {
    heaterOn = true;
    coolerOn = false;
  } else if (last_temp > high_temp_threshold) {
    heaterOn = false;
    coolerOn = true;
  }
}

/* ---- 5. Processor : Valeur de chaque %PLACEHOLDER% (4.1.1) ---- */
String processor(const String& var) {
  if (var == "UPTIME")      return String(millis() / 1000UL);
  if (var == "WHERE")       return F("Biot / Salle TP");
  if (var == "SSID")        return (WiFi.status() == WL_CONNECTED) ? WiFi.SSID() : F("Deconnecte");
  if (var == "MAC")         return WiFi.macAddress();
  if (var == "IP")          return (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : F("0.0.0.0");
  if (var == "TEMPERATURE") return String(last_temp, 2);
  if (var == "LIGHT")       return String(last_light);
  if (var == "COOLER")      return coolerOn ? F("ON") : F("OFF");
  if (var == "HEATER")      return heaterOn ? F("ON") : F("OFF");
  if (var == "LT")          return String(low_temp_threshold, 1);
  if (var == "HT")          return String(high_temp_threshold, 1);
  if (var == "PRT_IP")      return target_ip;
  if (var == "PRT_PORT")    return String(target_port);
  if (var == "PRT_T")       return String(target_sp);
  return String();
}

// Lecture et envoi de /index.html ligne par ligne (economise 90% de RAM)
void sendIndexHtmlStreaming() {
  if (!LittleFS.exists("/index.html")) {
    server.send(404, "text/plain", "Erreur: /index.html manquant dans LittleFS");
    return;
  }

  File file = LittleFS.open("/index.html", "r");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");

  while (file.available()) {
    String line = file.readStringUntil('\n') + "\n";
    // On ne cherche les placeholders que si la ligne contient le caractere '%'
    int firstPct = line.indexOf('%');
    while (firstPct != -1) {
      int secondPct = line.indexOf('%', firstPct + 1);
      if (secondPct == -1) break;
      String key = line.substring(firstPct + 1, secondPct);
      String val = processor(key);
      if (val.length() > 0) {
        line.replace("%" + key + "%", val);
        firstPct = line.indexOf('%');
      } else {
        firstPct = line.indexOf('%', secondPct + 1);
      }
    }
    server.sendContent(line);
  }
  file.close();
}

/* ---- 6. Construction du JSON dans le buffer statique (4.1.2 & 4.2) ---- */
void buildStatusJson() {
  StaticJsonDocument<512> doc;

  JsonObject status = doc.createNestedObject("status");
  status["temperature"] = last_temp;
  status["light"]       = last_light;
  status["led"]         = ledOn ? "on" : "off";
  status["fire"]        = fireDetected;
  status["running"]     = true;
  status["cooler"]      = coolerOn ? "ON" : "OFF";
  status["heater"]      = heaterOn ? "ON" : "OFF";

  JsonObject regul = doc.createNestedObject("regul");
  regul["lt"] = low_temp_threshold;
  regul["ht"] = high_temp_threshold;

  JsonObject info = doc.createNestedObject("info");
  info["loc"]   = "Biot";
  info["user"]  = "Soufiane";
  info["ident"] = "ESP32_01";

  JsonObject net = doc.createNestedObject("net");
  net["uptime"] = String(millis() / 1000UL);
  net["ssid"]   = (WiFi.status() == WL_CONNECTED) ? WiFi.SSID() : "Deconnecte";
  net["mac"]    = WiFi.macAddress();
  net["ip"]     = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : "0.0.0.0";

  JsonObject reporthost = doc.createNestedObject("reporthost");
  reporthost["target_ip"]   = target_ip;
  reporthost["target_port"] = target_port;
  reporthost["sp"]          = target_sp;

  serializeJson(doc, jsonBuffer, sizeof(jsonBuffer));
}

/* ---- 7. Envoi HTTP POST vers Node-RED (4.1.2) ---- */
void sendJsonToNodeRed() {
  if (target_sp <= 0 || target_ip.length() == 0 || WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = "http://" + target_ip + ":" + String(target_port) + "/esp?mac=" + WiFi.macAddress();
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.POST((uint8_t*)jsonBuffer, strlen(jsonBuffer));
  http.end();
}

/* ---- 8. Routes du Serveur Web (4.1.1 a 4.1.4) ---- */
void setupWebServer() {
  // [4.1.1] Page d'administration
  server.on("/", HTTP_GET, sendIndexHtmlStreaming);

  // Feuille de style CSS
  server.on("/esp.css", HTTP_GET, []() {
    const char* path = LittleFS.exists("/esp.css") ? "/esp.css" : "/style.css";
    if (LittleFS.exists(path)) {
      File f = LittleFS.open(path, "r");
      server.streamFile(f, "text/css");
      f.close();
    } else {
      server.send(404, "text/plain", "Not found");
    }
  });

  // Routes AJAX fetch() de index.html
  server.on("/temperature", HTTP_GET, []() {
    server.send(200, "text/plain", String(last_temp, 2));
  });

  server.on("/light", HTTP_GET, []() {
    server.send(200, "text/plain", String(last_light));
  });

  // [4.1.2] POST /target : Configuration du serveur de reporting
  server.on("/target", HTTP_POST, []() {
    if (server.hasArg("ip") && server.arg("ip").length() > 0)     target_ip   = server.arg("ip");
    if (server.hasArg("port") && server.arg("port").length() > 0) target_port = server.arg("port").toInt();
    if (server.hasArg("sp") && server.arg("sp").length() > 0)     target_sp   = server.arg("sp").toInt();
    sendIndexHtmlStreaming();
  });

  // [4.1.3] GET /value?temperature&light...
  server.on("/value", HTTP_GET, []() {
    int n = server.args();
    if (n == 0) {
      server.send(404, "text/plain", "404");
      return;
    }
    StaticJsonDocument<200> doc;
    for (int i = 0; i < n; i++) {
      String p = server.argName(i);
      if (p == "temperature") doc["temperature"] = last_temp;
      else if (p == "light")  doc["light"]       = last_light;
      else if (p == "fire")   doc["fire"]        = fireDetected;
      else if (p == "ht")     doc["ht"]          = high_temp_threshold;
      else if (p == "lt")     doc["lt"]          = low_temp_threshold;
      else {
        server.send(404, "text/plain", "404");
        return;
      }
    }
    char buf[200];
    serializeJson(doc, buf, sizeof(buf));
    server.send(200, "application/json", buf);
  });

  // [4.1.4] GET /set?cool=on&lt=18...
  server.on("/set", HTTP_GET, []() {
    int n = server.args();
    if (n == 0) {
      server.send(404, "text/plain", "404");
      return;
    }
    for (int i = 0; i < n; i++) {
      String name = server.argName(i);
      String val  = server.arg(i);
      val.toLowerCase();

      if (name == "cool") {
        if (val == "on" || val == "1")       { coolerOn = true;  ledOn = true;  digitalWrite(LEDpin, HIGH); }
        else if (val == "off" || val == "0") { coolerOn = false; ledOn = false; digitalWrite(LEDpin, LOW); }
        else { server.send(404, "text/plain", "404"); return; }
      } else if (name == "heat") {
        if (val == "on" || val == "1")       heaterOn = true;
        else if (val == "off" || val == "0") heaterOn = false;
        else { server.send(404, "text/plain", "404"); return; }
      } else if (name == "lt") {
        low_temp_threshold = val.toFloat();
      } else if (name == "ht") {
        high_temp_threshold = val.toFloat();
      } else if (name == "light_threshold") {
        light_threshold = val.toInt();
      } else if (name == "led") {
        ledOn = (val == "on" || val == "1");
        digitalWrite(LEDpin, ledOn ? HIGH : LOW);
      } else {
        server.send(404, "text/plain", "404");
        return;
      }
    }
    server.send(200, "text/plain", "OK");
  });

  // Routes de compatibilite
  server.on("/status", HTTP_GET, []() {
    buildStatusJson();
    server.send(200, "application/json", jsonBuffer);
  });

  server.onNotFound([]() {
    server.send(404, "text/plain", "404");
  });

  server.begin();
}

/* ---- 9. Setup & Loop ---- */
void setup() {
  Serial.begin(115200);
  pinMode(LEDpin, OUTPUT);
  digitalWrite(LEDpin, LOW);

  tempSensor.begin();
  updateSensorsAndRegulation();
  LittleFS.begin(true);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - start < 10000) {
    delay(500);
  }

  setupWebServer();
}

void loop() {
  server.handleClient();

  unsigned long period = (target_sp > 0) ? (target_sp * 1000UL) : 2000UL;
  if (millis() - last_tick >= period) {
    last_tick = millis();
    updateSensorsAndRegulation();

    if (target_sp > 0) {
      buildStatusJson();
      Serial.println(jsonBuffer);
      sendJsonToNodeRed();
    }
  }
}