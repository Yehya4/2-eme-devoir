/*
 * Projet IoT ESP32 Optimise Memoire (Flash & RAM)
 * Intégration HTTP + MQTT (TP Node-RED)
 */

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <HTTPClient.h>
#include <PubSubClient.h>      // Ajout pour MQTT
#include <LittleFS.h>
#include <ArduinoJson.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Adafruit_NeoPixel.h>

/* ---- 1. Configuration WiFi ---- */
const char* WIFI_SSID     = "Galaxy A124E16";
const char* WIFI_PASSWORD = "123456789";

/* ---- 2. Configuration MQTT & Reporting ---- */
String mqtt_server = "10.241.32.89"; // Broker MQTT modifiable dynamiquement
String mqtt_topic  = "uca/iot/master"; // Topic MQTT modifiable dynamiquement
int    mqtt_port   = 1883;

String target_ip   = "10.241.32.89"; // IP du PC (Node-RED en HTTP)
int    target_port = 1880;
int    target_sp   = 2;              // Periode en secondes
unsigned long last_tick = 0;

/* ---- 3. Materiel / GPIO & Variables d'etat ---- */
const uint8_t LEDpin      = 19;
const uint8_t LightPin    = 33;
const uint8_t NeoPixelPin = 18;
const uint16_t NumPixels  = 1;

OneWire oneWire(23);
DallasTemperature tempSensor(&oneWire);
Adafruit_NeoPixel pixels(NumPixels, NeoPixelPin, NEO_GRB + NEO_KHZ800);

WiFiClient espClient;
PubSubClient mqttClient(espClient); // Client MQTT

bool  ledOn        = false;
bool  coolerOn     = false;
bool  heaterOn     = false;
bool  fireDetected = false;
bool  firstRead    = true;
float last_temp    = 20.0f;
int   last_light   = 500;

float low_temp_threshold  = 19.0f;
float high_temp_threshold = 25.0f;
int   light_threshold     = 250;

WebServer server(80);
char jsonBuffer[512]; // Buffer statique unique

/* ---- 4. Lecture Capteurs, Lissage & Regulation ---- */
void updateSensorsAndRegulation() {
  tempSensor.requestTemperatures();
  float t = tempSensor.getTempCByIndex(0);
  int raw_light = analogRead(LightPin);

  float valid_temp = last_temp;
  if (t != DEVICE_DISCONNECTED_C && t > -50.0f && t < 84.0f) {
    valid_temp = t;
  }

  if (firstRead) {
    last_temp  = valid_temp;
    last_light = raw_light;
    firstRead  = false;
  } else {
    const float alpha = 0.8f; 
    last_temp  = (alpha * valid_temp) + ((1.0f - alpha) * last_temp);
    last_light = (int)((alpha * raw_light) + ((1.0f - alpha) * (float)last_light));
  }

  fireDetected = (last_temp > 30.0f);

  if (last_temp < low_temp_threshold) {
    heaterOn = true;
    coolerOn = false;
    ledOn    = false;
    digitalWrite(LEDpin, LOW);
  } else if (last_temp > high_temp_threshold) {
    heaterOn = false;
    coolerOn = true;
    ledOn    = true;
    digitalWrite(LEDpin, HIGH);
  } else {
    heaterOn = false;
    coolerOn = false;
    ledOn    = false;
    digitalWrite(LEDpin, LOW);
  }

  if (heaterOn || fireDetected) {
    pixels.setPixelColor(0, pixels.Color(255, 0, 0));   // Rouge
  } else if (coolerOn) {
    pixels.setPixelColor(0, pixels.Color(0, 0, 255));   // Bleu
  } else {
    pixels.setPixelColor(0, pixels.Color(0, 255, 0));   // Vert
  }
  pixels.show();
}

/* ---- 5. Processor : Valeur de chaque %PLACEHOLDER% ---- */
String processor(const String& var) {
  if (var == "UPTIME")      return String(millis() / 1000UL);
  if (var == "WHERE")       return F("Salle 312 - Les Lucioles");
  if (var == "SSID")        return (WiFi.status() == WL_CONNECTED) ? WiFi.SSID() : F("Deconnecte");
  if (var == "MAC")         return WiFi.macAddress();
  if (var == "IP")          return (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : F("0.0.0.0");
  if (var == "TEMPERATURE") return String(last_temp, 2);
  if (var == "LIGHT")       return String(last_light);
  if (var == "COOLER")      return coolerOn ? F("ON") : F("OFF");
  if (var == "HEATER")      return heaterOn ? F("ON") : F("OFF");
  if (var == "LT")          return String(low_temp_threshold, 1);
  if (var == "HT")          return String(high_temp_threshold, 1);
  if (var == "PRT_IP")      return target_ip;
  if (var == "PRT_PORT")    return String(target_port);
  if (var == "PRT_T")       return String(target_sp);
  if (var == "MQTT_IP")     return mqtt_server;
  if (var == "MQTT_TOPIC")  return mqtt_topic;
  return String();
}

void sendIndexHtmlStreaming() {
  if (!LittleFS.exists("/index.html")) {
    server.send(404, "text/plain", "Erreur: /index.html manquant dans LittleFS");
    return;
  }

  File file = LittleFS.open("/index.html", "r");
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html", "");

  while (file.available()) {
    String line = file.readStringUntil('\n') + "\n";
    int firstPct = line.indexOf('%');
    while (firstPct != -1) {
      int secondPct = line.indexOf('%', firstPct + 1);
      if (secondPct == -1) break;
      String key = line.substring(firstPct + 1, secondPct);
      String val = processor(key);
      if (val.length() > 0) {
        line.replace("%" + key + "%", val);
        firstPct = line.indexOf('%');
      } else {
        firstPct = line.indexOf('%', secondPct + 1);
      }
    }
    server.sendContent(line);
  }
  file.close();
}

/* ---- 6. Construction du JSON dans le buffer statique ---- */
void buildStatusJson() {
  StaticJsonDocument<512> doc;

  JsonObject status = doc.createNestedObject("status");
  status["temperature"] = serialized(String(last_temp, 2));
  status["light"]       = last_light;
  status["led"]         = ledOn ? "on" : "off";
  status["fire"]        = fireDetected;
  status["running"]     = true;
  status["cooler"]      = coolerOn ? "ON" : "OFF";
  status["heater"]      = heaterOn ? "ON" : "OFF";

  JsonObject regul = doc.createNestedObject("regul");
  regul["lt"] = low_temp_threshold;
  regul["ht"] = high_temp_threshold;

  JsonObject info = doc.createNestedObject("info");
  info["loc"]   = "Salle 312 - Les Lucioles";
  info["user"]  = "Soufiane";
  info["ident"] = "ESP32_01";

  JsonObject net = doc.createNestedObject("net");
  net["uptime"] = String(millis() / 1000UL);
  net["ssid"]   = (WiFi.status() == WL_CONNECTED) ? WiFi.SSID() : "Deconnecte";
  net["mac"]    = WiFi.macAddress();
  net["ip"]     = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : "0.0.0.0";

  JsonObject reporthost = doc.createNestedObject("reporthost");
  reporthost["target_ip"]   = target_ip;
  reporthost["target_port"] = target_port;
  reporthost["sp"]          = target_sp;

  serializeJson(doc, jsonBuffer, sizeof(jsonBuffer));
}

/* ---- 7. Envoi HTTP POST & MQTT vers Node-RED ---- */
void sendJsonToNodeRed() {
  if (target_sp <= 0 || target_ip.length() == 0 || WiFi.status() != WL_CONNECTED) return;

  HTTPClient http;
  String url = "http://" + target_ip + ":" + String(target_port) + "/esp?mac=" + WiFi.macAddress();
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.POST((uint8_t*)jsonBuffer, strlen(jsonBuffer));
  http.end();
}

void sendJsonToMQTT() {
  if (WiFi.status() != WL_CONNECTED) return;

  // Reconnexion automatique au broker MQTT si nécessaire
  if (!mqttClient.connected()) {
    String mqttClientId = "ESP32-";
    mqttClientId += WiFi.macAddress(); // ID unique basé sur l'adresse MAC
    
    if (mqttClient.connect(mqttClientId.c_str())) {
      Serial.println("Connecté au broker MQTT avec succès !");
    } else {
      Serial.print("Échec connexion MQTT, rc=");
      Serial.println(mqttClient.state());
    }
  }
  mqttClient.loop();

  // Publication sur le topic MQTT dynamique
  if (mqttClient.connected()) {
    mqttClient.publish(mqtt_topic.c_str(), jsonBuffer);
  }
}

/* ---- 8. Routes du Serveur Web ---- */
void setupWebServer() {
  server.on("/", HTTP_GET, sendIndexHtmlStreaming);

  server.on("/esp.css", HTTP_GET, []() {
    String path = LittleFS.exists("/esp.css") ? "/esp.css" : "/style.css";
    if (LittleFS.exists(path)) {
      File f = LittleFS.open(path, "r");
      server.streamFile(f, "text/css");
      f.close();
    } else {
      server.send(404, "text/plain", "Not found");
    }
  });

  server.on("/temperature", HTTP_GET, []() {
    server.send(200, "text/plain", String(last_temp, 2));
  });

  server.on("/light", HTTP_GET, []() {
    server.send(200, "text/plain", String(last_light));
  });

  server.on("/target", HTTP_POST, []() {
    if (server.hasArg("ip") && server.arg("ip").length() > 0)     target_ip   = server.arg("ip");
    if (server.hasArg("port") && server.arg("port").length() > 0) target_port = server.arg("port").toInt();
    if (server.hasArg("sp") && server.arg("sp").length() > 0)     target_sp   = server.arg("sp").toInt();
    sendIndexHtmlStreaming();
  });

  // Nouvelle route pour modifier la configuration MQTT à la volée
  server.on("/mqtt", HTTP_POST, []() {
    if (server.hasArg("mqtt_ip") && server.arg("mqtt_ip").length() > 0) {
      mqtt_server = server.arg("mqtt_ip");
    }
    if (server.hasArg("mqtt_topic") && server.arg("mqtt_topic").length() > 0) {
      mqtt_topic = server.arg("mqtt_topic");
    }
    mqttClient.setServer(mqtt_server.c_str(), mqtt_port);
    sendIndexHtmlStreaming();
  });

  server.on("/status", HTTP_GET, []() {
    buildStatusJson();
    server.send(200, "application/json", jsonBuffer);
  });

  server.onNotFound([]() {
    server.send(404, "text/plain", "404");
  });

  server.begin();
}

/* ---- 9. Setup & Loop ---- */
void setup() {
  Serial.begin(115200);
  pinMode(LEDpin, OUTPUT);
  digitalWrite(LEDpin, LOW);

  pixels.begin();
  pixels.setBrightness(50);
  pixels.clear();
  pixels.show();

  tempSensor.begin();
  updateSensorsAndRegulation();
  LittleFS.begin(true);

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  unsigned long start = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - start) < 10000) {
    delay(500);
  }

  // Configuration initiale du client MQTT
  mqttClient.setServer(mqtt_server.c_str(), mqtt_port);
  mqttClient.setBufferSize(512); // Important pour accepter la taille du JSON

  setupWebServer();
}

void loop() {
  server.handleClient();
  mqttClient.loop(); // Gestion des événements MQTT

  unsigned long period = (target_sp > 0) ? (target_sp * 1000UL) : 2000UL;
  if ((millis() - last_tick) >= period) {
    last_tick = millis();
    updateSensorsAndRegulation();

    if (target_sp > 0) {
      buildStatusJson();
      Serial.println(jsonBuffer);
      
      // Envois vers Node-RED (HTTP et MQTT)
      sendJsonToNodeRed();
      sendJsonToMQTT();
    }
  }
}